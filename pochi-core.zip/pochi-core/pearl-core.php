<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              emrahyldz.com
 * @since             1.0.0
 * @package           Pochi_Core
 *
 * @wordpress-plugin
 * Plugin Name:       Pochi Core
 * Plugin URI:        /
 * Description:       This plugin belongs to pearl.
 * Version:           1.0.0
 * Author:            emrah yıldız
 * Author URI:        emrahyldz.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pochi-core
 * Domain Path:       /languages
 */



/*==========================================
Custom Post Type
==========================================
*/
function pearl_custom_post_type()
{

$labels = array(
   'name' => 'Portfolio',
   'singular_name' => 'Portfolio',
   'add_new' => 'Add Item',
   'all_items' => 'All Items',
   'add_new_item' => 'Add Item',
   'edit_item' => 'Edit Item',
   'new_item' => 'New Item',
   'view_item' => 'View Item',
   'search_item' => 'Search Portfolio',
   'not_found' => 'No items found',
   'not_found_in_trash' => 'No items found in trash',
   'parent_item_colon' => 'Parent Item'
);
$args = array(
   'labels' => $labels,
   'public' => true,
   'has_archive' => true,
   'publicly_queryable' => true,
   'query_var' => true,
   'rewrite' => true,
   'capability_type' => 'post',
   'hierarchical' => false,
   'supports' => array(
	   'title',
	   'editor',
	   'excerpt',
	   'thumbnail',
	   'revisions',
   ),
   //'taxonomies' => array('field', 'post_tag'),
   'menu_position' => 5,
   'exclude_from_search' => false,
   'menu_icon' => 'dashicons-format-aside',
);
register_post_type('portfolio', $args);
}
add_action('init', 'pearl_custom_post_type');

function pearl_custom_taxonomies()
{

//add new taxonomy hierarchical
$labels = array(
   'name' => 'field',
   'singular_name' => 'field',
   'search_items' => 'Search Field',
   'all_items' => 'All Field',
   'parent_item' => 'Parent Field',
   'parent_item_colon' => 'Parent Field:',
   'edit_item' => 'Edit field',
   'update_item' => 'Update Field',
   'add_new_item' => 'Add New Work Field',
   'new_item_name' => 'New Field Name',
   'menu_name' => 'Field'
);

$args = array(
   'hierarchical' => true,
   'labels' => $labels,
   'show_ui' => true,
   'show_admin_column' => true,
   'query_var' => true,
   'rewrite' => array('slug' => 'field')
);

register_taxonomy('field', array('portfolio'), $args);

//add new taxonomy NOT hierarchical

/*	register_taxonomy('software', 'portfolio', array(
   'label' => 'Software',
   'rewrite' => array( 'slug' => 'software' ),
   'hierarchical' => false
) ); */
}

add_action('init', 'pearl_custom_taxonomies');

/*
==========================================
Custom Term Function
==========================================
*/

function pearl_get_terms($postID, $term)
{

$terms_list = wp_get_post_terms($postID, $term);
$output = '';

$i = 0;
foreach ($terms_list as $term) {
   $i++;
   if ($i > 1) {
	   $output .= ', ';
   }
   $output .= '<a href="' . get_term_link($term) . '">' . $term->name . '</a>';
}

return $output;
}
